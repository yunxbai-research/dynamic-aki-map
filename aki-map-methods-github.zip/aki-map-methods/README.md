# Dynamic AKI prediction and individualised MAP thresholds

This repository provides the model architecture, temporal feature processing,
training procedures and a runnable synthetic-data example for dynamic
postoperative acute kidney injury (AKI) prediction and model-derived mean
arterial pressure (MAP) thresholds.

**Study-trained models and patient-level study data are not distributed.**
This includes fitted CatBoost trees, neural-network weights, imputation values,
fitted categorical vocabularies, probability-calibration coefficients and
training-derived response-curve scales. These quantities are fitted afresh
within each run of the demonstration. The synthetic generator uses fixed
artificial distributions and does not read study records or checkpoints.

## Run the example

Use Python 3.11-3.13 in a new environment. The tested environment is listed in
`requirements.txt`. From the repository root:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pip install --no-deps -e .
python -m pytest -q
aki-map-demo --config configs/smoke.json --output outputs/demo
```

The example runs on CPU. It creates 120 synthetic development patients and 90
synthetic external patients, constructs the 112 pre-encoding features, performs
patient-level outer/inner cross-fitting, fits risk and response models, and
exports synthetic predictions, MAP thresholds, patient-balanced AUROC/AUPRC/
Brier metrics, a fold audit and an environment manifest under `outputs/demo`.
The output directory must be empty. No model files are saved.

The default smoke test retains the final architecture but uses 20 trees, two
response epochs, one model seed and 30 bootstrap replicates for speed. To run
the archived training hyperparameters on synthetic data:

```bash
aki-map-demo --config configs/research.json --patients 240 --output outputs/research-demo
```

That run is longer. All demonstration metrics are artificial and must not be
reported as study performance. An absent threshold can be a valid result of the
flat-curve rule, especially after the short smoke training.

## Contents

| Path | Content |
| --- | --- |
| `src/aki_map/temporal.py` | Archived source-aware 5-min binning and causal summary/window calculations |
| `src/aki_map/features.py` | Harmonised input adapter and final feature assembly |
| `src/aki_map/risk.py` | Two CatBoost ensembles, sampling and S1-assisted S2 calibration |
| `src/aki_map/network.py` | 64/32-unit native MAP-response network |
| `src/aki_map/response.py` | Response training, curve scaling and threshold inference |
| `src/aki_map/pipeline.py` | Outer evaluation and full-development external inference |
| `src/aki_map/selection.py` | Historical S1 candidate configurations and selection rule |
| `configs/research.json` | Final selected training hyperparameters and seeds |
| `configs/feature_order.json` | Exact final order of 112 pre-encoding features |
| `configs/ablation_nodes.json` | Seven historical input/feature sets, including the reference-model configurations |
| `docs/feature_dictionary.csv` | Definitions, units, windows, missingness and SHAP source labels |
| `docs/METHODS.md` | Formulas, sampling, cross-fitting and differences from the private execution environment |
| `docs/INPUTS.md` | Harmonised input schema and temporal boundaries |
| `docs/PUBLICATION.md` | Sharing statement, release scope and version notes |

The final model requires 13 clinical inputs and produces 112 pre-encoding
features. The number of encoded columns depends on the vocabulary fitted in
the training data. No study-trained category list is included.

## Reproducibility scope

The public package uses the final selected risk architecture associated with
`old14_final50_native_MAP_HI_v1`. Core temporal, sampling, calibration, response
and threshold methods were extracted from the archived code; their provenance
is recorded in `docs/source_provenance.json`. The portable runner replaces
institutional file paths and cached private datasets with harmonised input
tables and freshly generated data. It does not rerun the historical feature
search or reconstruct the original patient fold assignment. The private
response run used Apple MPS; the portable example uses CPU.

Synthetic examples demonstrate the algorithm, not independent reproduction of
the manuscript's estimates. The thresholds are model-derived research outputs;
the implementation does not establish a causal treatment effect.

## Licence and citation

This software is made available under the [PolyForm Strict License 1.0.0](LICENSE).
The full, unmodified licence text governs permitted uses, including its specific
organisational permissions. It does not grant permission to modify the software,
create new works based on it or redistribute it. Uses outside the granted scope
require separate permission from the rights holder. This is a source-available
release, not an open-source licence.

Study-trained model weights and fitted study parameters are not distributed
under this release. Add final bibliographic metadata and the public repository
URL when those details are finalised.

