# Publication and sharing scope

## Suggested code availability wording

The source code describing the model architecture, feature processing,
training procedures and MAP-threshold derivation is provided with a runnable
example using entirely synthetic data. The repository does not include
patient-level study data, trained study model weights, or fitted preprocessing,
calibration and response-scaling parameters. The synthetic example demonstrates
the computational workflow and does not reproduce the numerical study results.

Add the actual repository URL to that statement after publication of the
repository. A DOI or availability-on-request commitment should only be added
when it has actually been established. The scope of this code release should
be declared to the journal explicitly; this package does not assert that an
editor has accepted withholding trained study models.

## Current release

- Methods reference: `old14_final50_native_MAP_HI_v1`.
- Manuscript input terminology: 13 clinical inputs and 112 pre-encoding features.
- Seven historical ablation sets: 28/25/23/19/15/13/9 clinical inputs and
  177/153/150/146/142/112/106 pre-encoding features. Their feature membership is
  documented in `configs/ablation_nodes.json`; the runner uses the selected
  final architecture. Historical reference ablation fits used depth 4, 350
  iterations and L2 15 for both outcomes, and must not be confused with the
  final upgraded-S1/assisted-S2 model.
- Current external result populations in the manuscript: corrected INSPIRE
  17,864 and extended MOVER 4,616. No external patient records or predictions
  are present in this release, and these populations cannot be recreated by
  the synthetic generator.
- Archived training records establish CatBoost 1.2.10, NumPy 2.1.3, pandas
  2.3.3 and scikit-learn 1.7.2 for the S1 run. The precise historical Python,
  PyTorch and SciPy versions are untraceable. `requirements.txt` pins the
  separately tested public-example environment.
- Licence: PolyForm Strict License 1.0.0, provided verbatim in `LICENSE`.
  This source-available release is subject to that licence's permitted-purpose
  rules, including organisational permissions; it is not an open-source release.
  Final bibliographic metadata and the public repository URL remain to be added.

## Files intentionally excluded

No fitted trees, state dictionaries, calibration coefficients, fitted medians,
scaling arrays, category vocabularies, training-derived curve constants,
patient-level tables, real fold assignments, private file paths, credentials
or private result caches are included. Running the example creates artificial
CSV outputs in ignored directories and keeps its fitted model state in memory.

`tools/package_release.py` builds an allowlisted ZIP and checks for prohibited
binary formats, accidental local paths and symbolic links. Run it from the
repository root after tests. The ZIP itself contains source/configuration/
documentation only; generated output directories are excluded.

